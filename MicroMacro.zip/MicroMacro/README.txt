MicroMacro is a simple autoclicker type program that records your clicks and replays them for automation. 
Using this app, you could automatically open applications or do predetermined tasks to a limited degree. 
For example: I used it to set up a macro to open three applications that I always use together.

Controls:

Record Actions: Press this button to begin recording mouse clicks, you can add as many as you would like. If you hold down click, you will register several clicks which is convienent for spam-click heavy automation such as automating idle games.

Replay Actions: Replay your clicks once. This will follow the delay from the textbox below.

Repeat Actions: Replay your clicks an amount specified by the textbox below. This will also follow the delay from the other textbox below
WARNING: If the delay is too low and your repetitions are too high, this may lock your mouse for a while until you use a key combination to kill the program. (Recommended to use Ctrl+Alt+Del rather than Alt+F4 because you will likely not have the application selected)

Repetitions Box: Enter the amount of repetitions you would like to do. 

Delay Box: Enter, in miliseconds, the amount of time you want to have between clicks.

Exit: Ends the program.